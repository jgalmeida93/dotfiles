![](https://raw.githubusercontent.com/Murzchnvok/polybar-nord/master/polybar-nord.png)
![](https://raw.githubusercontent.com/Murzchnvok/polybar-nord/master/bspwm.png)

#### Font (SourceCodePro)
- [Nerd Fonts GitHub](https://github.com/ryanoasis/nerd-fonts)

#### Rofi Theme
- [Nord Rofi Theme](https://github.com/Murzchnvok/nord-rofi-theme)

#### Wallpaper
- [i3wm](https://drive.google.com/open?id=1VAz1QF7De_EI_EEqD-BI1pVrznGPFqfk)
- [bspwm](https://drive.google.com/open?id=1wsXH6lbi5PqzXkDG08Xg0yJpelQJ7gOY)
